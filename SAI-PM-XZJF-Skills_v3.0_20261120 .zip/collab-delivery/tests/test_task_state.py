import importlib.util
import unittest
from pathlib import Path

MODULE = Path(__file__).resolve().parents[1] / 'scripts' / 'task_state.py'
spec = importlib.util.spec_from_file_location('task_state', MODULE)
state = importlib.util.module_from_spec(spec)
spec.loader.exec_module(state)


class TaskStateTests(unittest.TestCase):
    def test_events_do_not_replace_stage(self):
        rows = [{'task_id': 'A', 'kind': k} for k in ['待收', '已接单', '已收到成果', '退回', '续期', '升级', '叫开工']]
        self.assertEqual(state.reduce_records(rows)['A']['stage'], '退回')

    def test_verified_without_acceptance_is_open(self):
        rows = [{'task_id': 'A', 'kind': '待收'}, {'task_id': 'A', 'kind': '已收到成果', 'verified': True}]
        self.assertFalse(state.reduce_records(rows)['A']['closed'])

    def test_acceptance_requires_evidence_and_authority(self):
        with self.assertRaises(ValueError):
            state.reduce_records([{'task_id': 'A', 'kind': '待收'}, {'task_id': 'A', 'kind': '已收到成果'}, {'task_id': 'A', 'kind': '已验收'}])

    def test_wrong_version_is_rejected(self):
        with self.assertRaises(ValueError):
            state.reduce_records(self.acceptance_rows('v2', 'v1'))

    @staticmethod
    def acceptance_rows(version='v1', verified='v1'):
        return [{'task_id': 'A', 'kind': '待收'}, {'task_id': 'A', 'kind': '已收到成果'}, {'task_id': 'A', 'kind': '已验收', 'version': version, 'verified_version': verified, 'evidence': 'review-1', 'accepted_by': 'user', 'acceptance_basis': 'request-1'}]

    def test_valid_acceptance_closes(self):
        self.assertTrue(state.reduce_records(self.acceptance_rows())['A']['closed'])

    def test_late_event_does_not_reopen(self):
        rows = self.acceptance_rows() + [{'task_id': 'A', 'kind': '升级'}, {'task_id': 'B', 'kind': '待收'}]
        result = state.reduce_records(rows)
        self.assertTrue(result['A']['closed'])
        self.assertFalse(result['B']['closed'])

    def test_closed_task_needs_new_id(self):
        with self.assertRaises(ValueError):
            state.reduce_records(self.acceptance_rows() + [{'task_id': 'A', 'kind': '待收'}])

    def test_cancellation_requires_authority(self):
        with self.assertRaises(ValueError):
            state.reduce_records([{'task_id': 'A', 'kind': '待收'}, {'task_id': 'A', 'kind': '已取消'}])
        result = state.reduce_records([{'task_id': 'A', 'kind': '待收'}, {'task_id': 'A', 'kind': '已取消', 'authority': 'user request'}])
        self.assertTrue(result['A']['closed'])

    def test_unknown_record_rejected(self):
        with self.assertRaises(ValueError):
            state.reduce_records([{'task_id': 'A', 'kind': '都好了'}])

    def test_missing_initial_registration_rejected(self):
        with self.assertRaises(ValueError):
            state.reduce_records([{'task_id': 'A', 'kind': '已接单'}])


if __name__ == '__main__':
    unittest.main()
