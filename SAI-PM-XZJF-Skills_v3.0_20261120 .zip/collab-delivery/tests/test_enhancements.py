import copy
import hashlib
import importlib.util
import json
import sys
import tempfile
import time
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / 'scripts'
sys.path.insert(0, str(SCRIPTS))
from task_contract import reduce_events
from host_adapter import Adapter, validate_native_record
from scenario_gate import REQUIRED, evaluate


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.policy = {'grants': [{'actor': a, 'actions': actions, 'task_ids': ['T'], 'scope': 'S'} for a, actions in [('owner', ['register', 'transition', 'accept', 'cancel', 'backfill', 'receive']), ('maker', ['produce']), ('checker', ['review']), ('lead', ['dispatch'])]]}
        self.artifact = self.save('product.txt', b'actual product')
        common = {'task_id': 'T', 'version': 'v1', 'scope': 'S', 'artifact_sha256': self.artifact['sha256'], 'source_ref': 'fixture-only-not-native'}
        self.review = self.save('review.json', dict(common, actor='checker', result='pass'))
        self.dispatch = self.save('dispatch.json', dict(common, actor='lead', result='sent', target='original'))
        self.receipt = self.save('receipt.json', dict(common, actor='owner', result='received', target='original', dispatch_sha256=self.dispatch['sha256']))
        self.rows = [self.event(1, '待收', actor='owner', version='v1', scope='S', producer='maker', return_to='original'), self.event(2, '已接单', actor='owner'), self.event(3, '已收到成果', actor='maker', version='v1', artifact=self.artifact), self.event(4, '已验收', actor='owner', version='v1', scope='S', artifact=self.artifact, review=self.review, dispatch=self.dispatch, receipt=self.receipt, return_to='original')]

    def save(self, name, value):
        data = value if isinstance(value, bytes) else json.dumps(value).encode()
        (self.root / name).write_bytes(data)
        return {'path': name, 'sha256': hashlib.sha256(data).hexdigest()}

    def event(self, seq, kind, **kw):
        return dict(task_id='T', event_id='E'+str(seq), seq=seq, at='2026-11-19T00:00:00Z', kind=kind, **kw)

    def run_rows(self, rows=None):
        return reduce_events(self.rows if rows is None else rows, self.root, self.policy)

    def test_four_files_closure(self):
        self.assertTrue(self.run_rows()['tasks']['T']['closed'])

    def test_illegal_backward(self):
        with self.assertRaises(ValueError):
            self.run_rows(self.rows[:3]+[self.event(4, '已接单', actor='owner')])

    def test_skip_requires_backfill(self):
        rows = [self.rows[0], dict(self.rows[2], event_id='E2', seq=2)]
        with self.assertRaises(ValueError):
            self.run_rows(rows)
        rows[1].update(mode='backfill', actor='maker', reason='restored actual record', source_ref='original')
        self.policy['grants'][1]['actions'].append('backfill')
        self.assertEqual(self.run_rows(rows)['tasks']['T']['stage'], '已收到成果')

    def test_duplicate_idempotency(self):
        self.assertEqual(self.run_rows(self.rows+[self.rows[-1]])['event_count'], 4)

    def test_duplicate_conflict(self):
        with self.assertRaises(ValueError):
            self.run_rows(self.rows+[dict(self.rows[-1], actor='other')])

    def test_out_of_order(self):
        with self.assertRaises(ValueError):
            self.run_rows([self.rows[0], dict(self.rows[1], seq=3)])

    def test_unknown_identity(self):
        self.rows[-1]['actor'] = 'stranger'
        with self.assertRaises(ValueError):
            self.run_rows()

    def test_wrong_scope(self):
        self.rows[-1]['scope'] = 'other'
        with self.assertRaises(ValueError):
            self.run_rows()

    def test_tampered_file(self):
        (self.root/'product.txt').write_bytes(b'changed')
        with self.assertRaises(ValueError):
            self.run_rows()

    def test_missing_dispatch(self):
        (self.root/'dispatch.json').unlink()
        with self.assertRaises(ValueError):
            self.run_rows()

    def test_receipt_wrong_dispatch(self):
        data = json.loads((self.root/'receipt.json').read_text())
        data['dispatch_sha256'] = '0'*64
        self.rows[-1]['receipt'] = self.save('receipt.json', data)
        with self.assertRaises(ValueError):
            self.run_rows()

    def test_self_review(self):
        data = json.loads((self.root/'review.json').read_text())
        data['actor'] = 'maker'
        self.rows[-1]['review'] = self.save('review.json', data)
        with self.assertRaises(ValueError):
            self.run_rows()

    def test_cancel_authorized(self):
        rows = self.rows[:2]+[self.event(3, '已取消', actor='owner', reason='request withdrawn')]
        self.assertTrue(self.run_rows(rows)['tasks']['T']['closed'])

    def test_reopen_forbidden(self):
        with self.assertRaises(ValueError):
            self.run_rows(self.rows+[self.event(5, '待收', actor='owner')])

    def test_process_event_keeps_stage(self):
        self.assertEqual(self.run_rows(self.rows[:2]+[self.event(3, '升级')])['tasks']['T']['stage'], '已接单')

    def test_path_escape(self):
        self.rows[2]['artifact']['path'] = '../outside'
        with self.assertRaises(ValueError):
            self.run_rows()

    def test_all_scenarios(self):
        for scenario, gates in REQUIRED.items():
            with self.subTest(scenario=scenario):
                report = {'scenario': scenario, 'checks': {g: {'status': 'pass', 'evidence': self.artifact, 'checked_by': 'observer', 'source_ref': 'fixture'} for g in gates}}
                self.assertTrue(evaluate(report, self.root)['passed'])
                report['checks'][gates[0]]['status'] = 'untested'
                self.assertFalse(evaluate(report, self.root)['passed'])


class AdapterTests(unittest.TestCase):
    def test_four_hosts_without_transport(self):
        for host in ['deepseek', 'grok', 'workbuddy', 'openmaus']:
            self.assertEqual(Adapter(host).invoke('probe', {})['status'], 'unsupported')

    def test_response_states(self):
        for status in ['ok', 'refused', 'permission_denied', 'attachment_failed', 'unsupported']:
            a = Adapter('grok', lambda *args: {'status': status, 'source_ref': 'synthetic'})
            self.assertEqual(a.invoke('dispatch', {'task_id':'T','request_id':'R'})['status'], status)

    def test_idempotency(self):
        calls = []
        a = Adapter('deepseek', lambda *args: calls.append(args) or {'status':'ok','source_ref':'synthetic'})
        p = {'task_id':'T','request_id':'R'}
        a.invoke('dispatch', p)
        a.invoke('dispatch', p)
        self.assertEqual(len(calls), 1)
        with self.assertRaises(ValueError):
            a.invoke('dispatch', dict(p, changed=True))

    def test_timeout_unknown(self):
        a = Adapter('openmaus', lambda *args: time.sleep(.02) or {'status':'ok','source_ref':'synthetic'})
        self.assertEqual(a.invoke('dispatch', {'task_id':'T','request_id':'R'}, timeout=.001)['status'], 'unknown')

    def test_native_record_no_fake_pass(self):
        with self.assertRaises(ValueError):
            validate_native_record({'status':'independently_verified'}, Path('.'))


if __name__ == '__main__':
    unittest.main()
