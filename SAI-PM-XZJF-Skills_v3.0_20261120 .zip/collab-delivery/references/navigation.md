# 协作交付规范 · 能力导航

本精简版只含认知执行层与可执行契约，不含任何上游源快照或历史素材。所有引用均指向本包内实存文件，按需加载，索引命中不等于正文已读。

## 认知执行层（按需加载）

| 当前需要 | 读取 |
|---|---|
| 建队、分工、制作—复审—交回 | [协作运行规范](coordination.md) |
| 派单、接单、等待、催收、改期、关闭 | [派收与状态机](dispatch.md) |
| 完成前核证据、退修、接受与收件 | [证据与交付](verification.md) |
| 给新手写实际操作步骤 | [操作说明](instructions.md) |
| 漏项复盘与效果边界 | [运营复盘](retrospective.md) |
| 启用岗位、群聊或直接交棒 | [岗位群规索引](organization.md) |
| 选择或核实宿主适配 | [平台适配索引](platforms.md) |
| 换会话、半成品续办或工具交接 | [接续与工具](continuity.md) |
| 规则转严格验收契约、八场景质量门 | [可执行契约说明](enhancements.md) |

## 可执行功能（scripts/）

- `task_contract.py`：严格验收入口，事件 ID、序号、带时区时间、owner 策略、四件摘要绑定。
- `task_state.py`：只读状态归并，仅作兼容，不作鉴权。
- `host_adapter.py`：宿主适配接口，未接 transport 一律 unsupported。
- `scenario_gate.py`：八类场景质量门，证据摘要 + 核验人 + 来源缺一不可。

## 契约与视图（contracts/）

- `capabilities.json`：能力分层（规则支持 / 代码实现 / 宿主验收）。
- `host-acceptance.json`：宿主原生验收矩阵，初始全部 untested。
- `scenarios.json`：八场景必查项与证据字段。
- `views.json`：单包多视图，路径是视图而非重复副本。
- `policy.example.json`：仅合成的 owner 授权策略示例，须替换为独立核实的真实策略。

## 模板与声明

- [任务及回件模板](../assets/task-and-receipt.md)
- 许可证与第三方声明：包根 `LICENSE`、`NOTICE`（依法保留的上游版权与许可文本，不属于产品标识）

## 使用纪律

启用岗位前读完整岗位节，启用群前读通则与具体群全文；索引与摘要不替代正文。缺少独立执行者时改人工审核或单人模式，不把同一模型自问自答算作独审。当前环境未亲测的加载、工具、权限与业务链一律标待验证。
