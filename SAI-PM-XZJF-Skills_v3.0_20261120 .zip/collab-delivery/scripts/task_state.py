import argparse
import json
from pathlib import Path

STAGES = {'待收', '已接单', '已收到成果', '退回', '已验收', '已取消'}
EVENTS = {'叫开工', '续期', '升级', '点名完', '已发送'}


def reduce_records(records):
    tasks = {}
    for record in records:
        task_id = record.get('task_id')
        kind = record.get('kind')
        if not isinstance(task_id, str) or not task_id:
            raise ValueError('task_id must be non-empty')
        if kind not in STAGES | EVENTS:
            raise ValueError(f'unknown kind: {kind}')
        if task_id not in tasks:
            if kind != '待收':
                raise ValueError(f'{task_id}: first record must be 待收')
            tasks[task_id] = {'stage': '待收', 'closed': False, 'events': []}
        task = tasks[task_id]
        if task['closed'] and kind in STAGES:
            raise ValueError(f'{task_id}: closed task cannot be reopened; use new ID')
        if kind == '已验收':
            required = ('version', 'verified_version', 'evidence', 'accepted_by', 'acceptance_basis')
            if any(not record.get(key) for key in required):
                raise ValueError(f'{task_id}: acceptance needs version, evidence and authority')
            if record['version'] != record['verified_version']:
                raise ValueError(f'{task_id}: accepted and verified versions differ')
            if task['stage'] != '已收到成果':
                raise ValueError(f'{task_id}: acceptance requires received deliverable')
        if kind == '已取消' and not record.get('authority'):
            raise ValueError(f'{task_id}: cancellation needs authority')
        if kind in STAGES:
            task['stage'] = kind
            task['closed'] = kind in {'已验收', '已取消'}
        else:
            task['events'].append(record)
    return tasks


def main():
    parser = argparse.ArgumentParser(description='Read-only task-stage reducer; does not dispatch or schedule.')
    parser.add_argument('records', type=Path, help='UTF-8 JSON array of append-only task records')
    args = parser.parse_args()
    try:
        tasks = reduce_records(json.loads(args.records.read_text(encoding='utf-8-sig')))
    except (ValueError, OSError, TypeError, KeyError) as exc:
        parser.exit(1, str(exc) + '\n')
    print(json.dumps({'tasks': tasks, 'unfinished': [key for key, item in tasks.items() if not item['closed']]}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
