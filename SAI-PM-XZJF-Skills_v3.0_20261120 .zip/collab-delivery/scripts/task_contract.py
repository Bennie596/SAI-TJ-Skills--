import hashlib
import json
from datetime import datetime
from pathlib import Path

TRANSITIONS = {
    '待收': {'已接单', '已取消'},
    '已接单': {'已收到成果', '已取消'},
    '已收到成果': {'退回', '已验收', '已取消'},
    '退回': {'已收到成果', '已取消'},
    '已验收': set(), '已取消': set(),
}
EVENTS = {'叫开工', '续期', '升级', '点名完', '已发送', '核验通过'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def local_file(root, relative):
    require(isinstance(relative, str) and relative and '\\' not in relative, 'use non-empty POSIX relative path')
    parts = relative.split('/')
    require(not relative.startswith('/') and ':' not in relative and all(p not in ('', '.', '..') for p in parts), 'unsafe relative path')
    base = Path(root).resolve()
    path = base.joinpath(*parts)
    current = base
    for part in parts:
        current = current / part
        require(not current.is_symlink() and not getattr(current, 'is_junction', lambda: False)(), 'links/junctions not allowed')
    require(path.resolve().is_relative_to(base) and path.is_file(), 'evidence file missing or outside root')
    return path


def fingerprint(root, item):
    require(isinstance(item, dict), 'evidence descriptor required')
    path = local_file(root, item.get('path'))
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    require(digest == item.get('sha256'), 'evidence fingerprint mismatch')
    return digest


def grant(policy, actor, action, task_id, scope):
    require(isinstance(policy, dict), 'trusted owner-supplied policy required')
    matches = [g for g in policy.get('grants', []) if g.get('actor') == actor and action in g.get('actions', []) and task_id in g.get('task_ids', []) and scope == g.get('scope')]
    require(bool(matches), 'actor/action/task/scope not authorized by trusted policy')


def check_closure(record, state, root, policy):
    version, scope = state['version'], state['scope']
    require(record.get('version') == version and record.get('scope') == scope, 'closure version/scope mismatch')
    grant(policy, record.get('actor'), 'accept', record['task_id'], scope)
    artifact = record.get('artifact', {})
    digest = fingerprint(root, artifact)
    require(artifact == state['artifact'], 'acceptance must bind received artifact')
    review_file = record.get('review', {})
    fingerprint(root, review_file)
    review = json.loads(local_file(root, review_file['path']).read_text(encoding='utf-8'))
    require(review.get('task_id') == record['task_id'] and review.get('version') == version and review.get('scope') == scope, 'review binding mismatch')
    require(review.get('artifact_sha256') == digest and review.get('result') == 'pass', 'review must pass exact artifact')
    require(review.get('actor') != state['producer'], 'self review forbidden')
    grant(policy, review.get('actor'), 'review', record['task_id'], scope)
    require(bool(review.get('source_ref')), 'review source reference required')
    require(record.get('return_to') == state['return_to'], 'return target changed')
    dispatch_item, receipt_item = record.get('dispatch', {}), record.get('receipt', {})
    dispatch_digest = fingerprint(root, dispatch_item)
    fingerprint(root, receipt_item)
    require(len({artifact['path'], review_file['path'], dispatch_item['path'], receipt_item['path']}) == 4, 'four independent files required')
    dispatch = json.loads(local_file(root, dispatch_item['path']).read_text(encoding='utf-8'))
    receipt = json.loads(local_file(root, receipt_item['path']).read_text(encoding='utf-8'))
    for data, action in [(dispatch, 'dispatch'), (receipt, 'receive')]:
        require(data.get('task_id') == record['task_id'] and data.get('scope') == scope and data.get('version') == version, 'delivery binding mismatch')
        require(data.get('artifact_sha256') == digest and data.get('target') == state['return_to'], 'delivery artifact/target mismatch')
        require(bool(data.get('source_ref')), 'delivery source reference required')
        grant(policy, data.get('actor'), action, record['task_id'], scope)
    require(dispatch.get('result') == 'sent' and receipt.get('result') == 'received', 'actual sent/received records required')
    require(receipt.get('dispatch_sha256') == dispatch_digest, 'receipt must bind exact dispatch')


def reduce_events(records, root, policy):
    require(isinstance(records, list), 'records must be an array')
    tasks, seen, last = {}, {}, {}
    for event in records:
        require(isinstance(event, dict), 'event object required')
        task_id, eid = event.get('task_id'), event.get('event_id')
        require(isinstance(task_id, str) and bool(task_id.strip()) and isinstance(eid, str) and bool(eid.strip()), 'task/event ID required')
        key = json.dumps(event, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
        if eid in seen:
            require(seen[eid] == key, 'event ID reused with changed payload')
            continue
        seq = event.get('seq')
        require(type(seq) is int and seq == last.get(task_id, 0) + 1, 'event sequence gap/out of order')
        stamp = datetime.fromisoformat(event.get('at', '').replace('Z', '+00:00'))
        require(stamp.tzinfo is not None, 'timezone-aware event timestamp required')
        kind = event.get('kind')
        require(kind in TRANSITIONS or kind in EVENTS, 'unknown event kind')
        if task_id not in tasks:
            require(kind == '待收', 'initial registration required')
            for field in ['version', 'scope', 'producer', 'return_to', 'actor']:
                require(isinstance(event.get(field), str) and bool(event[field].strip()), 'registration field missing: ' + field)
            grant(policy, event['actor'], 'register', task_id, event['scope'])
            tasks[task_id] = {k: event[k] for k in ['version', 'scope', 'producer', 'return_to']}
            tasks[task_id].update(stage='待收', history=[], events=[], closed=False, last_at=stamp.isoformat())
        else:
            state = tasks[task_id]
            require(stamp >= datetime.fromisoformat(state['last_at']), 'timestamp moved backwards')
            if kind in TRANSITIONS:
                require(not state['closed'], 'closed task needs a new ID')
                allowed = kind in TRANSITIONS[state['stage']]
                if not allowed:
                    require(event.get('mode') == 'backfill' and bool(event.get('reason')) and bool(event.get('source_ref')), 'illegal state transition')
                    require(kind not in {'已验收', '已取消', '待收'}, 'closure/registration cannot bypass transition')
                    grant(policy, event.get('actor'), 'backfill', task_id, state['scope'])
                if kind == '已收到成果':
                    require(event.get('actor') == state['producer'], 'received producer binding mismatch')
                    grant(policy, event.get('actor'), 'produce', task_id, state['scope'])
                    if event.get('version') != state['version']:
                        require(state['stage'] == '退回' and bool(event.get('change_ref')), 'version changes need revision basis')
                        require(isinstance(event.get('version'), str) and bool(event['version']), 'new version required')
                        state['version'] = event['version']
                    fingerprint(root, event.get('artifact'))
                    state['artifact'] = event['artifact']
                elif kind == '已验收':
                    check_closure(event, state, root, policy)
                elif kind == '已取消':
                    grant(policy, event.get('actor'), 'cancel', task_id, state['scope'])
                    require(bool(event.get('reason')), 'cancellation reason required')
                else:
                    grant(policy, event.get('actor'), 'transition', task_id, state['scope'])
                state['stage'] = kind
                state['closed'] = kind in {'已验收', '已取消'}
            else:
                state['events'].append(event)
            state['last_at'] = stamp.isoformat()
        tasks[task_id]['history'].append(event)
        seen[eid], last[task_id] = key, seq
    return {'tasks': tasks, 'event_count': len(seen), 'trust_boundary': 'policy and source authenticity must be independently established; file hashes do not authenticate people'}


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Strict read-only task, evidence, delivery and authority contract verifier')
    parser.add_argument('records', type=Path)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--policy', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = reduce_events(json.loads(args.records.read_text(encoding='utf-8-sig')), args.root, json.loads(args.policy.read_text(encoding='utf-8-sig')))
    except (ValueError, TypeError, KeyError, OSError) as error:
        parser.exit(1, str(error) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
