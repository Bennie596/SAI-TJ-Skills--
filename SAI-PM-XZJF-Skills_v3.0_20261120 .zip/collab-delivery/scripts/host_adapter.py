import json
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError
from pathlib import Path
from task_contract import require, fingerprint

OPERATIONS = {'probe', 'bind', 'dispatch', 'status', 'read_artifact', 'review', 'receipt', 'cancel', 'recover'}
PLATFORMS = {'deepseek', 'workbuddy', 'grok', 'openmaus'}


class Adapter:
    def __init__(self, platform, transport=None):
        require(platform in PLATFORMS, 'unknown platform')
        self.platform, self.transport = platform, transport
        self.completed = {}

    def invoke(self, operation, payload, timeout=5):
        require(operation in OPERATIONS, 'unknown operation')
        require(isinstance(payload, dict) and timeout > 0, 'invalid request')
        if self.transport is None:
            return {'status': 'unsupported', 'platform': self.platform, 'operation': operation, 'native_verified': False, 'reason': 'no authorized host transport bound'}
        require(bool(payload.get('task_id')) and bool(payload.get('request_id')), 'task/request ID required')
        key = payload['request_id']
        identity = json.dumps([operation, payload], sort_keys=True)
        if key in self.completed:
            old_identity, result = self.completed[key]
            require(identity == old_identity, 'request ID payload conflict')
            return result
        pool = ThreadPoolExecutor(max_workers=1)
        future = pool.submit(self.transport, self.platform, operation, payload)
        try:
            raw = future.result(timeout=timeout)
        except TimeoutError:
            result = {'status': 'unknown', 'reason': 'timeout; remote completion unknown; reconcile by request ID before any retry', 'native_verified': False}
            self.completed[key] = identity, result
            return result
        except Exception as error:
            result = {'status': 'unknown', 'reason': 'transport error: ' + type(error).__name__, 'native_verified': False}
            self.completed[key] = identity, result
            return result
        finally:
            pool.shutdown(wait=False, cancel_futures=True)
        require(isinstance(raw, dict) and raw.get('status') in {'ok', 'refused', 'permission_denied', 'attachment_failed', 'unsupported', 'unknown'}, 'invalid transport response')
        result = dict(raw, platform=self.platform, operation=operation, native_verified=False)
        if raw['status'] == 'ok':
            require(bool(raw.get('source_ref')), 'successful host response needs trace reference')
            self.completed[key] = identity, result
        return result


def validate_native_record(record, root):
    for field in ['platform', 'host_version', 'install_method', 'role', 'operation', 'checked_by', 'at', 'source_ref']:
        require(bool(record.get(field)), 'native record missing: ' + field)
    require(record['platform'] in PLATFORMS and record['operation'] in OPERATIONS, 'unknown platform/operation')
    require(record.get('status') in {'independently_verified', 'reported', 'untested', 'failed'}, 'invalid capability status')
    if record['status'] == 'independently_verified':
        fingerprint(root, record.get('evidence'))
        require(record.get('real_host') is True and record.get('checked_by') != record.get('actor'), 'independent real-host observer required')
    return record


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description='Fail-closed four-host capability facade; no native client or credentials bundled')
    p.add_argument('platform', choices=sorted(PLATFORMS))
    p.add_argument('operation', choices=sorted(OPERATIONS))
    args = p.parse_args()
    print(json.dumps(Adapter(args.platform).invoke(args.operation, {}), ensure_ascii=False, indent=2))
