import csv
import hashlib
import json
from pathlib import Path
from task_contract import require, local_file, fingerprint

REQUIRED = {
    'content': ['facts_checked', 'rights_checked', 'style_checked', 'release_authorized'],
    'software': ['reproduction_checked', 'build_passed', 'tests_passed', 'independent_review'],
    'data': ['source_checked', 'schema_checked', 'independent_recalculation', 'dirty_data_test'],
    'media': ['format_checked', 'rendered_or_played', 'visual_review', 'rights_checked'],
    'private': ['least_privilege', 'redacted', 'access_denial_test', 'retention_defined'],
    'long_task': ['checkpoint_verified', 'single_owner', 'resume_diff_checked', 'no_duplicate_send'],
    'batch': ['idempotency_test', 'rate_limit_test', 'cancel_test', 'fault_injection'],
    'enterprise': ['identity_verified', 'tenant_isolation_test', 'approval_trace', 'audit_retention'],
}


def evaluate(report, root):
    scenario = report.get('scenario')
    require(scenario in REQUIRED, 'unknown scenario')
    failures = []
    for name in REQUIRED[scenario]:
        check = report.get('checks', {}).get(name, {})
        if check.get('status') != 'pass':
            failures.append(name + ': not passed')
            continue
        try:
            fingerprint(root, check.get('evidence'))
            require(bool(check.get('checked_by')) and bool(check.get('source_ref')), 'observer/source required')
        except (ValueError, TypeError, OSError) as error:
            failures.append(name + ': ' + str(error))
    return {'scenario': scenario, 'passed': not failures, 'failures': failures, 'scope': 'verifies evidence files and declared outcomes; does not independently prove visual quality, isolation or external authorization'}


if __name__ == '__main__':
    import argparse
    p = argparse.ArgumentParser(description='Eight-scenario evidence gate')
    p.add_argument('report', type=Path)
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    result = evaluate(json.loads(a.report.read_text(encoding='utf-8')), a.root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result['passed'] else 1)
