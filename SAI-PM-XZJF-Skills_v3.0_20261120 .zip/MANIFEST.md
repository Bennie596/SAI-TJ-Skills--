# 结构清单

- 包标识：`协作交付规范-精简独立版Skills_v3.0_20261120`
- 技能 slug：`collab-delivery`
- 契约版本：1；技能版本：3.0.0；日期：2026-11-20
- 许可：MIT（见 `LICENSE`；第三方声明见 `NOTICE`）

## 顶层

| 文件 | 作用 |
|---|---|
| `README.md` | 说明、来源、清单、复现、校验、边界 |
| `MANIFEST.md` | 本清单 |
| `LICENSE` | 上游版权与许可文本，依法保留 |
| `NOTICE` | 第三方许可与权利声明，依法保留 |
| `collab-delivery/` | 技能主体 |

## collab-delivery/

| 路径 | 文件 |
|---|---|
| 入口 | `SKILL.md` |
| `references/` | navigation, coordination, dispatch, verification, instructions, retrospective, organization, platforms, continuity, enhancements（10 篇） |
| `scripts/` | task_contract.py, task_state.py, host_adapter.py, scenario_gate.py（4 个） |
| `contracts/` | capabilities.json, host-acceptance.json, policy.example.json, scenarios.json, views.json（5 份） |
| `assets/` | task-and-receipt.md |
| `tests/` | test_enhancements.py, test_task_state.py |
| 法律文本 | `collab-delivery/NOTICE`（技能目录内副本） |

## 相对 v2.1 的变更

1. 去产品标识：改中文名、slug、显示名与全部正文中的产品名表述。
2. 删上游快照：`references/upstream/` 全部 840 文件及内嵌 zip / pdf / mp4 / 站点素材。
3. 删维护与溯源工程产物：`tools/`、`evidence/`、交付台账、逐文件映射、两份 github-tree.json。
4. 剔除依赖被删目录的测试 `test_release.py`，保留自洽的 2 组测试。
5. 重写 `SKILL.md`、`navigation.md`，修正 `views.json`、`enhancements.md`、`platforms.md`、`continuity.md`、`retrospective.md` 中对已删内容的引用。
